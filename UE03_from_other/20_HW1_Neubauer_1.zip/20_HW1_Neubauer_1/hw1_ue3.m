% Signal Analysis - Exercise Homework 1
% Example 3
% Thomas Neubauer

close all
clear all
clc

% Nr Samples
N = 5e3;

% Create ADC Object
X_m = 2; 
B   = 4;
ADC = func_createQuantizer(X_m,B);

delta = X_m/(2^B);

% % Plot quantizer curve
% func_plotQuantizer( ADC ,1 ,'b')

% Sampling Frequency
ADC.f_S = 1E3;

%T Jitter
ADC.Tjitter = 1E-6;   % T Jitter varies with your ID number

%% Betrachtung einzelner Frequenzen

sig = @(t,PAR) PAR.A*sin(2*pi*PAR.f*t+PAR.phi);

PAR.A = 1;      %Amplitude
PAR.f = 39;     % Frequency 
PAR.phi = 0;    % Phase

t = (0:N-1)/ADC.f_S;

% How to run func_ADC
id = 20; % your ID
[x,xSH,xQ,xSHQ] = func_ADC(sig,PAR,N,id);

diff = xQ - x;

figure,set(gca,'FontSize',22),set(gcf,'Color','White');
grid on;
histogram(diff);
title(['Histogramm bei f = ' num2str(PAR.f) 'Hz']),set(gca,'FontSize',22);

figure,set(gca,'FontSize',22),set(gcf,'Color','White');
plot(t(450:550),x(450:550),t(450:550),xQ(450:550),'r--','LineWidth',1.5);
legend('Eingangssignal x','quantisiertes Signal xQ'),set(gca,'FontSize',22);
grid on;
xlabel('t / s'),set(gca,'FontSize',22);
ylabel('x, xQ'),set(gca,'FontSize',22);
title('Quantisierung des Eingangssignal (Ausschnitt)'),set(gca,'FontSize',22);

figure,set(gca,'FontSize',22),set(gcf,'Color','White')
stem(t(350:700),diff(350:700));
legend(['Quantisierungsfehler f = ' num2str(PAR.f) 'Hz']);
grid on;
xlabel('t / s'),set(gca,'FontSize',22);
ylabel('e = xQ - x'),set(gca,'FontSize',22);
title('Quantisierungsfehler (Ausschnitt)'),set(gca,'FontSize',22);

diff_mean = ones(1,N);
diff_mean(:) = mean(diff);

figure;
stem(t,diff);
hold on
plot(t,diff_mean,'LineWidth',1.5);
hold off
legend(['Quantisierungsfehler f = ' num2str(PAR.f) 'Hz'],['e_{mean} = ' num2str(diff_mean(1),3)]),set(gca,'FontSize',22);
grid on;
xlabel('t in s'),set(gca,'FontSize',22);
ylabel('e = xQ - x'),set(gca,'FontSize',22);
title('Quantisierungsfehler'),set(gca,'FontSize',22);

%% Betrachtung mehrerer Frequenzen
freq = [1:1:(ADC.f_S/2)-1]; % create frequencies
num_freq = length(freq); % number of frequencies

for i = 1:num_freq
    sig = @(t,PAR) PAR.A*sin(2*pi*PAR.f*t+PAR.phi);

    PAR.A = 1;      %Amplitude
    PAR.f = freq(i); % Frequency
    PAR.phi = 0;    % Phase

    t = (0:N-1)/ADC.f_S;
    
    % How to run func_ADC
    id = 20; % your ID
    [x,xSH,xQ,xSHQ] = func_ADC(sig,PAR,N,id);

    % Quantization Error
    diff(i,:) = xQ - x;
    diff_mean(i,:) = mean(diff(i,:));

end

figure,set(gca,'FontSize',22),set(gcf,'Color','White')
plot(diff_mean,'LineWidth',1.5);
grid on;
xlabel('f / Hz'),set(gca,'FontSize',22);
ylabel('e_{mean}'),set(gca,'FontSize',22);
title('Durchschnittlicher Quantisierungsfehler je Frequenz'),set(gca,'FontSize',22);

%% Dithering

PAR.f=250;

low_bnd = -delta/2;
up_bnd = delta/2; 
w=(up_bnd-low_bnd).*rand(1,N)+low_bnd; % disturbance

figure,set(gca,'FontSize',22),set(gcf,'Color','White');
plot(w);
grid on;
title('Gleichverteiltes St�rsignal w(t)'),set(gca,'FontSize',22);

id = 20; % your ID
[x,xSH,xQ_dist,xSHQ] = func_ADC(sig,PAR,N,id);

x_dist = x+w; % x with disturbance

% Quantization Error disturbed
diff_dist = xQ_dist - x_dist;
diff_mean_dist = mean(diff_dist);

figure,set(gca,'FontSize',22),set(gcf,'Color','White');
stem(t,diff_dist);
% hold on
% plot(t,diff_mean_dist,'LineWidth',1.5);
% hold off
legend(['Quantisierungsfehler f = ' num2str(PAR.f) 'Hz']),set(gca,'FontSize',22); %['e_{mean} = ' num2str(diff_mean_dist(1),3)]
grid on;
xlabel('t in s'),set(gca,'FontSize',22);
ylabel('e = xQ - x'),set(gca,'FontSize',22);
title('Quantisierungsfehler bei Dithering'),set(gca,'FontSize',22);

figure,set(gca,'FontSize',22),set(gcf,'Color','White');
grid on;
histogram(diff_dist);
title(['Quantisierungsfehler bei f = ' num2str(PAR.f) 'Hz mit Dithering']),set(gca,'FontSize',22);


for i = 1:num_freq
    
    PAR.f = freq(i); % Frequency
    
    low_bnd = -delta/2;
    up_bnd = delta/2; 
    w=(up_bnd-low_bnd).*rand(1,N)+low_bnd; % disturbance
    
    id = 20; % your ID
    [x,xSH,xQ_dist,xSHQ] = func_ADC(sig,PAR,N,id);
    
    x_dist = x+w; % x with disturbance

    % Quantization Error disturbed
    diff_dist(i,:) = xQ_dist - x_dist;
    diff_mean_dist(i,:) = mean(diff_dist(i,:));
    
end

figure,set(gca,'FontSize',22),set(gcf,'Color','White')
plot(diff_mean_dist,'LineWidth',1.5);
grid on;
xlabel('f / Hz'),set(gca,'FontSize',22);
ylabel('e_{mean,dithered}'),set(gca,'FontSize',22);
title('Durchschnittlicher Quantisierungsfehler bei Dithering'),set(gca,'FontSize',22);

% Effective number of bits
sig = @(t,PAR) PAR.A*sin(2*pi*PAR.f*t+PAR.phi);
PAR.A = 1;      %Amplitude
PAR.f = 39;     % Frequency 
PAR.phi = 0;    % Phase

t = (0:N-1)/ADC.f_S;

id = 20; % your ID
[x,xSH,xQ,xSHQ] = func_ADC(sig,PAR,N,id);

P_sig = var(x); % Signalleistung
P_noise = X_m^2/(2^(2*B)*12); % Rauschleistung
P_noise=(2/(2*N-1))*sum((abs((xQ-x))).^2);

SINAD = 10*log10(P_sig/P_noise) %SINAD
ENOB = (SINAD-1.76)/6.02

%% Sample & Hold

sig = @(t,PAR) PAR.A*sin(2*pi*PAR.f*t+PAR.phi);
PAR.A = 1;      % Amplitude
PAR.f = 39;     % Frequency 
PAR.phi = 0;    % Phase

t = (0:N-1)/ADC.f_S;

freq = [1:1:(ADC.f_S/2)-1]; % create frequencies
num_freq = length(freq); % number of frequencies

for i = 1:num_freq
    PAR.f = freq(i);
    id = 20; % your ID
    [x,xSH,xQ,xSHQ] = func_ADC(sig,PAR,N,id);
    
    %P_noise = X_m^2/(2^(2*B)*12); % Rauschleistung 
    P_noise=(2/(2*N-1))*sum((abs((xSH-x))).^2);
    P_sig = var(xSH); % Signalleistung
    
    SNR(i) = 10*log10(P_sig/P_noise);
end

figure,set(gca,'FontSize',22),set(gcf,'Color','White')
plot(freq,SNR,'LineWidth',1.5)
grid on
xlabel('f / Hz'),set(gca,'FontSize',22);
ylabel('SNR / dB'),set(gca,'FontSize',22);
title('SNR Sample & Hold (xSH)'),set(gca,'FontSize',22);


% find aperture jitter
% see Kester2009

f_lo = 1; 
f_hi = (ADC.f_S/2)-1; % as high as possible

id=20;

% untere Frequenz
PAR.f = f_lo; 
[x_lo,xSH_lo,xQ_lo,xSHQ_lo] = func_ADC(sig,PAR,N,id);

% obere Frequenz
PAR.f = f_hi; 
[x_hi,xSH_hi,xQ_hi,xSHQ_hi] = func_ADC(sig,PAR,N,id);

% SNR low
P_sig_lo = var(x_lo);
P_noi_lo =(2/(2*N-1))*sum((abs((xSHQ_lo-x_lo))).^2);
SNR_lo = 10*log10(P_sig_lo/P_noi_lo);

% SNR high
P_sig_hi = var(x_hi); 
P_noi_hi =(2/(2*N-1))*sum((abs((xSHQ_hi-x_hi))).^2);
SNR_hi = 10*log10(P_sig_hi/P_noi_hi); 

% Jitter Delay
t_a = 1/(2*pi*f_hi) * sqrt( (10^(-SNR_hi/20))^2 - (10^(-SNR_lo/20))^2  );
t_a = abs(t_a)

% tj=(1/(2*pi*f))*(1/(10^(SNR_lo/20))); % alternativ f�r eine Frequenz

%% Overall S&H + Quantization

sig = @(t,PAR) PAR.A*sin(2*pi*PAR.f*t+PAR.phi);
PAR.A = 1;      % Amplitude
PAR.f = 39;     % Frequency 
PAR.phi = 0;    % Phase

t = (0:N-1)/ADC.f_S;

freq = [1:1:499]; % create frequencies
num_freq = length(freq); % number of frequencies

SNR = zeros(1,length(freq));
ENOB = zeros(1,length(freq));

for i = 1:num_freq
    PAR.f = freq(i);
    id = 20; % your ID
    [x,xSH,xQ,xSHQ] = func_ADC(sig,PAR,N,id);
    
    %P_noise = X_m^2/(2^(2*B)*12); % Rauschleistung 
    P_noise =(2/(2*N-1))*sum((abs((xSHQ-x))).^2);
    P_sig = var(xSHQ); % Signalleistung
    
    SNR(1,i) = 10*log10(P_sig/P_noise);
    ENOB(1,i) = (SNR(1,i)-1.76)/6.02;
end

figure,set(gca,'FontSize',22),set(gcf,'Color','White')
    subplot(2,1,1);
        plot(freq,SNR,'LineWidth',1.5);
        grid on;
        xlabel('f / Hz'),set(gca,'FontSize',22);
        ylabel('SNR / dB'),set(gca,'FontSize',22);
        title('SNR von xSHQ'),set(gca,'FontSize',22);
    subplot(2,1,2);
        plot(freq,ENOB,'LineWidth',1.5);
        grid on;
        xlabel('f / Hz'),set(gca,'FontSize',22);
        ylabel('ENOB / bit'),set(gca,'FontSize',22);
        title('ENOB von xSHQ'),set(gca,'FontSize',22);