function [ x ] = func_Gauss_LCG(N,a,c,m,x0)


X = zeros(N,length(x0));
%X(1,:) = linspace(0,m,NG);

X(1,:) = x0(:)';

for jj = 1:length(x0)
   for  ii = 2:N;

      X(ii,jj) = mod(a *X(ii-1,jj) + c,m); 
    
   end
end

X = 2*(X/m-0.5);
x = sum(X,2);

end

