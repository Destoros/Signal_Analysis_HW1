function Hest = absolute_neu(F,y)
  N = 1024;
  win = hann(N);
  [kk_1 vec]=xcorr(y,y,'unbiased');
  Rauschleistung=kk_1(find(vec==0))-kk_1(find(vec==0)+1);
  [Sxx,wx] = pwelch(F,win,N/2,[],'onesided');
  [Syy,wx] = pwelch(y,win,N/2,[],'onesided');
  Hest = sqrt((max(Syy)-Rauschleistung)/max(Sxx));
  
%   kk_1=xcorr(y,'unbiased');
%   Rauschleistung=kk_1(floor(length(kk_1)/2)+1)-kk_1(floor(length(kk_1)/2)+2);
%   r_xx=xcorr(F,'unbiased');
%   r_yy=xcorr(y,'unbiased');
%   Hest=100*abs(r_yy(floor(length(r_yy)/2)+1)-Rauschleistung)/r_xx(floor(length(r_xx)/2)+1);
end