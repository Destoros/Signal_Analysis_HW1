function phi=get_phase_delay(F,y,W,Td)
%returns the phase delay in degrees
Numlags=100;
XCF=crosscorr(F,y,'NumLags',Numlags,'NumSTD',2);
i=0;
while XCF(Numlags+1+i) <= XCF(Numlags+2+i) || XCF(Numlags+1+i) < 0
    i=i+1;
end
phi=-360/(2*pi)*W*i*Td;
end