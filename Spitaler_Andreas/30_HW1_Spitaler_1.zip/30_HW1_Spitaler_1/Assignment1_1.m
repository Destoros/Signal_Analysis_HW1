clc
clear all
close all

%% 1.A.)
id=30;
m=10;
c=450;
d=10;

A=[0       1;
   -c/m   -d/m];
b=[0 1/m].';
c=[1 0].';
d=0;
sys=ss(A,b,c.',d);
H=tf(sys);
W=0:0.1:100;
[H_resp]=freqs(H.Numerator{1,1},H.Denominator{1,1},W);

figure
 freqs(H.Numerator{1,1},H.Denominator{1,1},W) %freqs -> freqs res im s-Bereich

%Discuss
Omega_res=6.7 % resonanzfrequenz

%% 1.B und C.)
F_max=1.4;
Signalpower_F=(F_max^2)/2
Td=pi/300;
Numlags=100;
Phase=zeros(100,1);
Absolute=zeros(100,1);
i=zeros(100,1);
a = 1664525; c = 21767; m = 2^32;
%Number of Samples
N = 1E5;

%Random Initialization
x0 = floor(m*rand(1,5));
[x] = func_Gauss_LCG(N,a,c,m,x0);
x=0.8*x*10^-3;  % Sigma=0.001m
t=0:1:(length(x)-1);
W=10;
F=F_max*sin(W*t*Td);
 
y=mass_spring_system(F,Td,id)+x;       %Simulation und addieren der St�rung
y=y(10000:end);                        %ersten 10000 Samples einschwingen!!
F=F(10000:end);
t = [0:1:length(y)-1]*Td;

%Vergleichsplot eingangs und Ausgangssignal
figure, 
 hold on
 grid on
 plot(t,y,'r'), 
 plot(t,F/1000,'b')
 xlabel('t in s')
 ylabel('y(t) in m')
 legend('y','F/1000')
 axis([0 4 -5E-3 5E-3])
 title('Input and output of the system at omega = 10 rad/s')

%%
%Versuch autokorr noise
kk_1=xcorr(y,y,'unbiased');
x_axis=[-floor(length(kk_1)/2):1:floor(length(kk_1)/2)];

figure
 plot(x_axis,kk_1)
 grid on
 axis([-100 100 -0.000005 0.000005])
 xlabel('n')
 ylabel('r_{yy}')
 title('Autocorrelation of the output')
%%
i=1;
%identifikationsloop
for W=1:0.1:20
  i=i+1;
  t=0:Td:(length(x)-1)*Td;
  F=F_max*sin(W*t);
  y=mass_spring_system(F,Td,id)+x;       %Simulation und addieren der St�rung
  y=y(10000:end);                        %ersten 10000 Samples einschwingen!!
  F=F(10000:end);
  Phase(i)=get_phase_delay(F,y,W,Td);    % mit crosscorr
  Absolute(i)=absolute_(F,y);            % mit xcorr
end

%%
figure
  plot(1:0.1:20.1,Phase)
  grid on
  title('Phase(H(j\Omega))')
  xlabel('\Omega in rad/s')
  ylabel('Phase(H(j\Omega)) in �')
  
figure
  plot(1:0.1:20.1,Absolute)
  grid on
  title('|H(j\Omega)|')
  xlabel('\Omega in rad/s')
  ylabel('|H(j\Omega)| in 1')
  
% Begr�ndung f�r die Wahl der SA Methode
% Es wurde die Kreuzkorrelation gew�hlt, weil hier das Rauschen durch den
% phasenunterschied zwischen Ein und Ausgangssignal wegf�llt. Die phase
% kann durch die Zeitliche verschiebung des ersten Peaks in der Korrelation
% ermittelt werden. Der Betragsgang ergibt sich durch S4 ausarbeitung!!

%% 1.D.)
a = 1664525; c = 21767; m = 2^32;
%Number of Samples
N = 1E5;

%Random Initialization
x0 = floor(m*rand(1,5));
[x] = func_Gauss_LCG(N,a,c,m,x0);

% �berpr�fen ob signal power < 1
F1=0.7*x;  % Sigma=0.001m
XCR=xcorr(F1,F1,'unbiased');
% figure
%  plot(XCR)
Sig_pwr=XCR(1e+5)

%Simulation ohne Messrauschen
y1=mass_spring_system(F1,Td,id);
y1=y1(10000:end);                        %ersten 10000 Samples einschwingen!!
F1=F1(10000:end);
% figure
%  hold on
%  plot(y1,'r')
%  plot(F1,'b')
 
%Sch�tzung onesided
%hier wird die Frequenz in 2*pi angegeben und der Betrag stimmt ohnehin
N = 1024;
win = hann(N);

[Sxx,w1] = pwelch(F1,win,N/2,[],'onesided');
[Syy,w2] = pwelch(y1,win,N/2,[],'onesided');

Hest = sqrt(Syy./Sxx);

figure
  plot(w1,abs(Hest))
  grid on
  title('|H(e^{j\omega})|')
  xlabel('\omega in rad/s')
  ylabel('|H(e^{j\omega})|')
  
%% Simulation mit Messrauschen
a = 1664525; c = 21767; m = 2^32;
N = 1E5;
x0 = floor(m*rand(1,5));
[x] = func_Gauss_LCG(N,a,c,m,x0);
F2=0.7*x;  % Sigma=0.001m

%Random Initialization
a = 1664525; c = 21767; m = 2^32;
x0 = floor(m*rand(1,5));
[x2] = func_Gauss_LCG(N,a,c,m,x0);
x2=0.8*x2*10^-3;  % Sigma_x2 != 0.001m
Sigma_x2=sqrt(var(x2))

y2=mass_spring_system(F2,Td,id);
y2=y2+x2(1:length(y2));
y2=y2(10000:end);                        %ersten 10000 Samples einschwingen!!
F2=F2(10000:end);
sig_pwr_F2=var(F2)

%Sch�tzung twosided
N = 1024;
win = hann(N);

[Sxx,w1] = pwelch(F2,win,N/2,[],'onesided');
[Syy,w2] = pwelch(y2,win,N/2,[],'onesided');

Hest = sqrt(Syy./Sxx);

figure
  plot(w1,abs(Hest))
  grid on
  title('|H(e^{j\omega})|')
  xlabel('\omega in rad/s')
  ylabel('|H(e^{j\omega})|')
  
%% versuch entfernen des Messraauschens
% AKF von y2 ohne eingangssignal -> es gibt nur das Messrauschen am ausgang
[AKF_x2 vec_x2]=xcorr(x2,'unbiased'); 
noise_pwr=AKF_x2(find(vec_x2==0))

[Sxx,wxx] = pwelch(F2,win,N/2,[],'onesided');
[Syy,wyy] = pwelch(y2,win,N/2,[],'onesided');
[Sx2x2,wx2x2] = pwelch(x2,win,N/2,[],'onesided');
Hest2 = sqrt((Syy-Sx2x2)./Sxx);

figure
  plot(wxx,abs(Hest2))
  grid on
  title('|H(e^{j\omega})|')
  xlabel('\omega in rad/s')
  ylabel('|H(e^{j\omega})|')

%% 1.E)
Td=pi/300;
id=30;
t = [0:1:100000]*Td;
k=10;
F=k*t;
y=mass_spring_system(F,Td,id);
figure
  hold on
  plot(t,y,'r')
  plot(t,F)
[gamma_xy_C wC]=mscohere(F,y);         %aus C)

figure
  plot(wC/pi,gamma_xy_C)
  title('Behaviour of the system/function y = mass\_spring\_system(F,Td,id)')
  grid on
  xlabel('\omega/\pi')
  ylabel('\gamma_{xy}')
  axis([0 1 0 1.2])