clear all
close all
clc

load('Filtercoeff');
f_S=2000;

H0=tf(lowpass,1,1/f_S);
H1=tf(highpass,1,1/f_S);


%% 2.A.)

[H0_,W0_]=freqz(H0.Numerator{1,1},H0.Denominator{1,1});
[H1_,W1_]=freqz(H1.Numerator{1,1},H1.Denominator{1,1});

figure('Name','Lowpass')
%   subplot(2,1,1);
  hold on
  plot(W0_,abs(H0_),'g')
  plot(W1_,abs(H1_),'b')
  xlabel('\omega')
  ylabel('abs()')
  legend('Lowpass','Highpass')
  title('Absolute Values of the Filters')
  
%% 2.B.)
H_x_x1=H1;
H_x_x2=tf(conv(H0.Numerator{1, 1}  ,  upsample(H1.Numerator{1, 1},2)),1,f_S);
H_x_x3=tf(conv(H0.Numerator{1, 1}  ,  upsample(conv(H0.Numerator{1, 1}  ,  upsample(H1.Numerator{1, 1},2)),2)),1,f_S);
H_x_x4=tf(conv(H0.Numerator{1, 1}  ,  upsample(conv(H0.Numerator{1, 1}  ,  upsample(H0.Numerator{1, 1},2)),2)),1,f_S);

[H1_,W1_]=freqz(H_x_x1.Numerator{1,1},H_x_x1.Denominator{1,1});
[H2_,W2_]=freqz(H_x_x2.Numerator{1,1},H_x_x2.Denominator{1,1});
[H3_,W3_]=freqz(H_x_x3.Numerator{1,1},H_x_x3.Denominator{1,1});
[H4_,W4_]=freqz(H_x_x4.Numerator{1,1},H_x_x4.Denominator{1,1});

figure('Name','Comparison')
  hold on
  plot(W1_,db(abs(H1_)),'g')
  plot(W2_,db(abs(H2_)),'b')
  plot(W3_,db(abs(H3_)),'k')
  plot(W4_,db(abs(H4_)),'c')
  xlabel('\omega')
  ylabel('abs() in dB')
  legend('H_{xx1}','H_{xx2}','H_{xx3}','H_{xx4}')
  title('Frequency response of all paths')

%% 2.D.)
%Estimation of the PSD Twosided
N = 1024;
win = hann(N);
t=(0:1/f_S:1/f_S*1E5);
f = linspace(0,f_S/2,N/2+1);

Hest_xx1=zeros(1,length(f));
Hest_xx2=zeros(1,length(f));
Hest_xx3=zeros(1,length(f));
Hest_xx4=zeros(1,length(f));

for k=1:length(f)
   x=sin(2*pi*f(k)*t);
  [Sxx,wx] = pwelch(x,win,N/2,[],'onesided');
  [x1,t1,x2,t2,x3,t3,x4,t4]=func_filterbank(x,f_S,H0.Numerator{1, 1},H1.Numerator{1, 1});
  [Sx1x1,wx1x1] = pwelch(x1,win,N/2,[],'onesided');
  [Sx2x2,wx2x2] = pwelch(x2,win,N/2,[],'onesided');
  [Sx3x3,wx3x3] = pwelch(x3,win,N/2,[],'onesided');
  [Sx4x4,wx4x4] = pwelch(x4,win,N/2,[],'onesided');
  Hest_xx1(k) = 20*log10(sqrt(max(Sx1x1)/max(Sxx)));    % achtung die PSD am Ausgang ist auf der 1/2 bzw. 1/4 bzw 1/8 frequ. der eingangs frequ. des Sinus
  Hest_xx2(k) = 20*log10(sqrt(max(Sx2x2)/max(Sxx)));
  Hest_xx3(k) = 20*log10(sqrt(max(Sx3x3)/max(Sxx)));
  Hest_xx4(k) = 20*log10(sqrt(max(Sx4x4)/max(Sxx)));
end
%%
figure
 hold on
 plot(f,Hest_xx1,'g')
 plot(f,Hest_xx2,'k')
 plot(f,Hest_xx3,'c')
 plot(f,Hest_xx4)
 ylabel('|H(z)| in dB')
 xlabel('f_{x} in Hz')
 legend('H_{xx1}','H_{xx2}','H_{xx3}','H_{xx4}')

%% 2.E.)
load('UE2sig')
[x1,t1,x2,t2,x3,t3,x4,t4]=func_filterbank(x,f_S,H0.Numerator{1, 1},H1.Numerator{1, 1});
figure('Name','Response')
  subplot(4,1,1);
  title('x1[n]')
  hold on
  plot(t1,x1)
  xlabel('time in s')
  ylabel('x1[n]')
  subplot(4,1,2); 
  title('x2[n]')
  hold on
  plot(t2,x2)
  xlabel('time in s')
  ylabel('x2[n]')
  subplot(4,1,3); 
  title('x3[n]')
  hold on
  plot(t3,x3)
  xlabel('time in s')
  ylabel('x3[n]')
  subplot(4,1,4); 
  title('x4[n]')
  hold on
  plot(t4,x4)
  xlabel('time in s')
  ylabel('x4[n]')
  
tx=(0:1/f_S:1/f_S*(length(x)-1))
figure
  title('x[n]')
  plot(tx,x)
  xlabel('time in s')
  ylabel('x[n]')
  
figure
  spectrogram(x,4,0,4,f_S)
  
figure
subplot(5,1,1)
  spectrogram(x,256,0,256,f_S)
subplot(5,1,2)
  spectrogram(x1,256,0,256,f_S/2)
subplot(5,1,3)
  spectrogram(x2,256,0,256,f_S/4)
subplot(5,1,4)
  spectrogram(x3,256,0,256,f_S/8)
subplot(5,1,5)
  spectrogram(x4,256,0,256,f_S/8)
  
%% Test
f=300;
t=(0:1/f_S:1/f_S*1E5);
x=sin(2*pi*f*t);
[x1,t1,x2,t2,x3,t3,x4,t4]=func_filterbank(x,f_S,H0.Numerator{1, 1},H1.Numerator{1, 1});
figure('Name','Response')
  subplot(4,1,1);
  title('x1[n]')
  hold on
  plot(t1,x1)
  xlabel('time in s')
  ylabel('x1[n]')
  subplot(4,1,2); 
  title('x2[n]')
  hold on
  plot(t2,x2)
  xlabel('time in s')
  ylabel('x2[n]')
  subplot(4,1,3); 
  title('x3[n]')
  hold on
  plot(t3,x3)
  xlabel('time in s')
  ylabel('x3[n]')
  subplot(4,1,4); 
  title('x4[n]')
  hold on
  plot(t4,x4)
  xlabel('time in s')
  ylabel('x4[n]')