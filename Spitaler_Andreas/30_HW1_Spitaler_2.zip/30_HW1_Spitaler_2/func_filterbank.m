function [x1,t1,x2,t2,x3,t3,x4,t4]=func_filterbank(x,f_S,h0,h1)
Td=1/f_S;
x1=upfirdn(x,impz(h1),1,2);
t1=(0:2*Td:2*Td*(length(x1)-1));
x2_=upfirdn(x,impz(h0),1,2);
x2=upfirdn(x2_,impz(h1),1,2);
t2=(0:4*Td:4*Td*(length(x2)-1));
x3_=upfirdn(x2_,impz(h0),1,2);
x3=upfirdn(x3_,impz(h1),1,2);
t3=(0:8*Td:8*Td*(length(x3)-1));
x4=upfirdn(x3_,impz(h0),1,2);
t4=(0:8*Td:8*Td*(length(x4)-1));
end